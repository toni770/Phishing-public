from django.urls import path
from . import views



urlpatterns = [
    path('', views.index, name='index'),
    path('cliente/<str:empresa>', views.empresa_auditar, name='empresa-auditar'),
    path('crearEmpresa', views.crear_empresa, name='crear-empresa'),
    path('crearCorreo', views.crear_correo, name='crear-correo'),
    path('borrarEmpresa/<str:empresa>', views.borrar_empresa, name='borrar-empresa'),
    path('borrarCorreo/<str:correo>', views.borrar_correo, name='borrar-correo'),
    path('phishing/<str:correo>', views.phishing, name='phishing'),
    path('logins/<str:correo>/<str:servicio>', views.login_bases, name='login-bases'),
    path('imagenes/<str:correo>/<str:logo>', views.imagenes, name='login-bases'),

    # path('logins/<str:correo>/<str:servicio>/aviso', views.login_bases, name='aviso'),
]