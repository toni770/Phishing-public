from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Empresas, Correos, Plantillas, Credenciales
from .forms import EmpresaForm, CorreoForm, DeleteForm, PhishingForm
from .emailsPhishing import enviar
import threading

# Create your views here.
 

@login_required(login_url='/accounts/login/')
def crear_empresa(request):

    empresaForm = EmpresaForm(request.POST)
    print("Nombre a guardar de la empresa : " + request.POST['nombre'])
    empresa = request.POST['nombre']
    if empresaForm.is_valid():
        print("Guardando..")
        empresaForm.save()
        print("Guardado exitosamente!")

    return redirect('empresa-auditar', empresa)





@login_required(login_url='/accounts/login/')
def crear_correo(request):
        
    correoForm = CorreoForm(request.POST)
    print("Nombre a guardar de la empresa : " + request.POST['empresa'])
    empresa = Empresas.objects.filter(id = request.POST['empresa'])
    print("correo a guardar : " + request.POST['correo'])
    if correoForm.is_valid():
        print("Guardando..")
        correoForm.save()
        print("Guardado exitosamente!")

    return redirect('empresa-auditar', empresa[0].nombre)




@login_required(login_url='/accounts/login/')
def borrar_empresa(request, empresa=None):
    

    if request.POST['delete'] == 'delete':
        print("Eliminando "+empresa)
        Empresas.objects.filter(nombre = empresa).delete()
        print("Eliminado exitosamente!")
    else:
        print("No se puede eliminar")

    return redirect('index')



@login_required(login_url='/accounts/login/')
def borrar_correo(request, correo=None):
    correoObj = Correos.objects.filter(id = correo)
    print("Eliminando correo " + correoObj[0].correo)
    empresa = correoObj[0].empresa
    if request.POST['delete'] == 'delete':

        correoObj.delete()
        print("Eliminado exitosamente!")
    else:
        print("No se puede eliminar")

    return redirect('empresa-auditar', empresa)




@login_required(login_url='/accounts/login/')
def phishing(request, correo=None):
    print(correo)
    print(request.POST)
    if request.POST['phishing'] == 'phishing':
        print("Mandando phishing a " + correo)
        servicio = Plantillas.objects.filter(id = request.POST['servicio'])
        print("Servicio: " + servicio[0].servicio)
        enviar(servicio[0].email, servicio[0].password, correo, servicio[0].asunto, servicio[0].mensaje)

        print("Phishing exitosamente!")
    else:
        print("No se puede phishing")

    return redirect('index')





@login_required(login_url='/accounts/login/')
def index(request):
    empresaForm = EmpresaForm()
    correoForm = CorreoForm()
    empresas = Empresas.objects.all()
    data = {
            'empresas': empresas,
            'form_empresa' : empresaForm,
            'form_correo' : correoForm,
    }
    
        
    return render(request, 'frontend/index.html', data)






@login_required(login_url='/accounts/login/')
def empresa_auditar(request, empresa=None): 

    empresaForm = EmpresaForm()
    correoForm = CorreoForm()
    deleteForm = DeleteForm()
    phishingForm = PhishingForm()

    data = {
        'empresas' : Empresas.objects.all(),
        'empresa_actual' : empresa,
        'correos' : Correos.objects.filter(empresa__nombre=empresa),
        'credenciales' :Credenciales.objects.filter(correo__empresa__nombre = empresa),
        'plantillas' : Plantillas.objects.all(),
        'form_empresa' : empresaForm,
        'form_correo' : correoForm,
        'form_delete' : deleteForm,
        'form_phishing' : phishingForm,
    }
    
    if request.method == 'GET':

        return render(request, 'frontend/index.html', data)

    elif request.method == 'POST':

        print("estoy en el post")


    return render(request, 'frontend/index.html', data)





def login_bases(request, servicio=None, correo=None):

    print(correo)

    if request.method == 'GET':

        data ={

            'servicio' : servicio,
            'correo' : correo,
        }

        correos = Correos.objects.all()

        for i in correos:
            

            if i.correo == correo:
                print("El correo existe")
                # aki se tiene k poner el estatus web TRUE de credenciales donde objects.filter(correo__correo == i.correo) 
                print("ESTATUS WEB : TRUE " + i.correo)
                return render(request, 'logins/'+servicio+'.html', data)
            

        return redirect('index')

    if request.method == 'POST':

        usuario = request.POST['usuario']
        contraseña = request.POST['contraseña']
        print("Usuario: " + usuario)
        print("Contraseña: " + contraseña)
        print("Servicio: " + servicio)
        print("IP: " + request.META.get('REMOTE_ADDR'))

        data = {
            'usuario': usuario,
            'contraseña': contraseña,
            'servicio': servicio,
            'ip': request.META.get('REMOTE_ADDR')
        }

        return render(request, 'logins/aviso.html', data)




def imagenes(request, logo=None, correo=None):

    if request.method == 'GET':

        data ={

            'ruta' : "logos/"+logo+".png",
            'logo' : logo,
            'correo' : correo,
        }
        correos = Correos.objects.all()

        for i in correos:
            

            if i.correo == correo:
                print("El correo existe")
                # aki se tiene k poner el estatus web TRUE de credenciales donde objects.filter(correo__correo == i.correo) 
                print("ESTATUS MAIL : TRUE " + i.correo)
                return render(request, 'imagenes/logos.html', data)
    return redirect('index')
