from redmail import outlook


def enviar(usuario, contraseña, destino, asunto, contenido):
    print("Enviando correo")
    print("Usuario: " + usuario)
    print("Contraseña: " + contraseña)
    print("Destino: " + destino)
    print("Asunto: " + asunto)
    print("Contenido: " + contenido)


    outlook.username = usuario
    outlook.password = contraseña

    outlook.send(
        receivers=[destino],
        subject=asunto,
        text=contenido,
    )