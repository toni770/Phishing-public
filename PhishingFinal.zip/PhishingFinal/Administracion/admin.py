from django.contrib import admin

# Register your models here.

from .models import Credenciales, Empresas, Correos, Plantillas

admin.site.register(Credenciales)
admin.site.register(Empresas)
admin.site.register(Correos)
admin.site.register(Plantillas)